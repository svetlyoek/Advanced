﻿using System;
using System.Linq;

namespace GenericScale
{
    public class StartUp
    {
      public  static void Main(string[] args)
        {
            var item = new EqualityScale<int>(10, 7);
            Console.WriteLine(item.AreEqual());
        }
    }
}
