﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CompanyRoster
{
    public class StartUp
    {
        public static void Main()
        {
            var employees = new List<Employee>();

            int employeesCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < employeesCount; i++)
            {
                string[] lines = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                string name = lines[0];
                double salary = double.Parse(lines[1]);
                string position = lines[2];
                string department = lines[3];

                var employee = new Employee(name, salary, position, department);

                if (lines.Length > 4)
                {
                    var ageOrEmail = lines[4];

                    if (ageOrEmail.Contains('@'))
                    {
                        employee.Email = ageOrEmail;
                    }
                    else
                    {
                        employee.Age = int.Parse(ageOrEmail);
                    }
                }

                if (lines.Length > 5)
                {
                    employee.Age = int.Parse(lines[5]);
                }

                employees.Add(employee);
            }

            var result = employees
                    .GroupBy(e => e.Department)
                    .Select(e => new
                    {
                        Department = e.Key,
                        AverageSalary = e.Average(emp => emp.Salary),
                        Employees = e.OrderByDescending(emp => emp.Salary)
                    })
                    .FirstOrDefault();


            Console.WriteLine($"Highest Average Salary: {result.Department}");

            foreach (var employee in result.Employees.OrderByDescending(x=>x.Salary))
            {
                Console.WriteLine($"{employee.Name} {employee.Salary:F2} {employee.Email} {employee.Age}");


            }
        }
    }
}

