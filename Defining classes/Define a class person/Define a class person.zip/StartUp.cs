﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var firstPerson = new Person("Pesho", 20);

            var secondPerson = new Person("Gosho", 18);

            var thirdPerson = new Person("Stamat", 43);



        }
    }
}
